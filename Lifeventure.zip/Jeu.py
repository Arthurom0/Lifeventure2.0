from Mechant import *

#classe qui représente le jeu
class Jeu: 
    def __init__(self):
        self.pressed = {}
       


