# Lifeventure2.0
game for NSI
this file is a project for school and the request was to do a game with pygame. 
this game is a 2D adventure game in which the character moves around through a few maps to save smt 
